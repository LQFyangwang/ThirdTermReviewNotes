package com.gs.common;

import org.junit.Test;

/**
 * Created by Administrator on 2017/12/7.
 */
public class CheckCodeUtilsTest {

    @Test
    public void testCheckCode() {
        System.out.println(CheckCodeUtils.randomCode());
    }
}
