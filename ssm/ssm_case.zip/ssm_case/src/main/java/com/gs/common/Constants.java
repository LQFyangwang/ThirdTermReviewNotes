package com.gs.common;

/**
 * Created by Administrator on 2017/12/7.
 */
public class Constants {

    public static final String CODE_IN_SESSION = "code";
    public static final String USER_IN_SESSION = "user";
}
