package com.gs.service;

/**
 * Created by Administrator on 2017/12/7.
 */
public interface PayTypeService extends BaseService {
}
