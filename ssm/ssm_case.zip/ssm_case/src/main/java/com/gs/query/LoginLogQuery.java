package com.gs.query;

/**
 * Created by Administrator on 2017/12/12.
 */
public class LoginLogQuery {

    private String phone;
    private String loginTime;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getLoginTime() {
        return loginTime;
    }

    public void setLoginTime(String loginTime) {
        this.loginTime = loginTime;
    }
}
