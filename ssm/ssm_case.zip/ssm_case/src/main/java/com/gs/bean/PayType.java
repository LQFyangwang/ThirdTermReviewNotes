package com.gs.bean;

/**
 * Created by Administrator on 2017/12/4.
 */
public class PayType {
    private Long id;
    private String type;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

}
