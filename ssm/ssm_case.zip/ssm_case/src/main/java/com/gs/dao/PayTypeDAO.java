package com.gs.dao;

import com.gs.bean.PayType;
import org.springframework.stereotype.Repository;

/**
 * Created by Administrator on 2017/12/7.
 */
@Repository
public interface PayTypeDAO extends BaseDAO {
}
