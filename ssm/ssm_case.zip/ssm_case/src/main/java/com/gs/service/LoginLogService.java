package com.gs.service;

/**
 * Created by Administrator on 2017/12/7.
 */
public interface LoginLogService extends BaseService {

    void updateByUserId(Long userId);
}
