package com.gs.vo;

/**
 * Created by Administrator on 2017/12/11.
 */
public class CashTypeVO {

    private Long id;
    private String type;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
